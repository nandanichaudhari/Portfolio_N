'use client'

import { ExternalLink, Github } from 'lucide-react'
import Image from 'next/image'

const projects = [
  {
    title: 'E-Voting System',
    description: 'AI-powered secure voting application with face recognition, blockchain verification, and JWT authentication.',
    image: 'https://images.unsplash.com/photo-1611532736579-6b16e2b50449?w=500&h=300&fit=crop',
    tags: ['React Native', 'Node.js', 'AI/ML', 'Blockchain', 'JWT'],
    github: '#',
    demo: '#',
  },
  {
    title: 'Skin Disease Prediction',
    description: 'ML/DL-powered web app using deep learning to predict skin conditions from images for better healthcare access.',
    image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=500&h=300&fit=crop',
    tags: ['Python', 'Django', 'Machine Learning', 'React', 'HTML/CSS'],
    github: '#',
    demo: '#',
  },
  {
    title: 'Complaint Management Portal',
    description: 'Full-stack web application for efficient complaint submission, tracking, and resolution with Spring Boot backend.',
    image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=300&fit=crop',
    tags: ['Java', 'Spring Boot', 'MySQL', 'HTML/CSS', 'JavaScript'],
    github: '#',
    demo: '#',
  },
  {
    title: 'ATM Management System',
    description: 'Desktop application for managing ATM transactions, account balances, and user authentication with Java Swing.',
    image: 'https://images.unsplash.com/photo-1633356713697-ca91e44f5b5f?w=500&h=300&fit=crop',
    tags: ['Java', 'Swing', 'DBMS', 'MySQL', 'OOP'],
    github: '#',
    demo: '#',
  },
  {
    title: 'Food Delivery Dashboard',
    description: 'Real-time order tracking and delivery management dashboard with responsive UI and REST API integration.',
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561404?w=500&h=300&fit=crop',
    tags: ['React', 'Node.js', 'MongoDB', 'Express.js', 'Tailwind CSS'],
    github: '#',
    demo: '#',
  },
  {
    title: 'Portfolio Website',
    description: 'Modern, responsive portfolio showcasing projects and skills with smooth animations and dark mode support.',
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=500&h=300&fit=crop',
    tags: ['Next.js', 'React', 'Tailwind CSS', 'TypeScript', 'Framer Motion'],
    github: '#',
    demo: '#',
  },
]

export function ProjectsSection() {
  return (
    <section id="projects" className="py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <div className="inline-block px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
            <span className="text-accent text-sm font-semibold">PORTFOLIO</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold">Featured Projects</h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Showcasing real-world projects that solve problems and deliver value
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-xl border border-border bg-card/50 backdrop-blur-sm hover:border-accent/50 transition-all duration-300 hover:shadow-lg hover:shadow-accent/10"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden bg-secondary/20">
                <Image
                  src={project.image}
                  alt={project.title}
                  width={500}
                  height={300}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                <div>
                  <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                  <p className="text-foreground/70 text-sm leading-relaxed">{project.description}</p>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 rounded text-xs bg-accent/10 text-accent border border-accent/20"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* Links */}
                <div className="flex gap-3 pt-4 border-t border-border">
                  <a
                    href={project.github}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-secondary/20 hover:bg-secondary/40 transition-colors text-sm font-medium"
                    aria-label={`${project.title} GitHub`}
                  >
                    <Github size={16} />
                    Code
                  </a>
                  <a
                    href={project.demo}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-accent/20 hover:bg-accent/30 text-accent transition-colors text-sm font-medium"
                    aria-label={`${project.title} Live Demo`}
                  >
                    <ExternalLink size={16} />
                    Demo
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <p className="text-foreground/70 mb-6">Want to see more projects?</p>
          <a
            href="https://github.com/nandanichaudhari"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3 rounded-lg border border-accent text-accent hover:bg-accent/10 font-semibold transition-all duration-200"
          >
            Visit My GitHub
            <ExternalLink size={20} />
          </a>
        </div>
      </div>
    </section>
  )
}
