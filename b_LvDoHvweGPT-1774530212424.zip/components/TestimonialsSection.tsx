'use client'

import { Star } from 'lucide-react'

const testimonials = [
  {
    name: 'Rajesh Kumar',
    role: 'Tech Lead, StartupXYZ',
    content: 'Nandani delivered exceptional results on our web application. Her attention to detail and quick turnaround time were impressive.',
    rating: 5,
  },
  {
    name: 'Priya Sharma',
    role: 'Product Manager, FinTech Solutions',
    content: 'Outstanding work on the API integration project. She understood our requirements perfectly and delivered clean, scalable code.',
    rating: 5,
  },
  {
    name: 'Amit Patel',
    role: 'Founder, Digital Agency',
    content: 'Professional, reliable, and highly skilled. Would definitely work with her again on future projects.',
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <div className="inline-block px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
            <span className="text-accent text-sm font-semibold">TESTIMONIALS</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold">What Clients Say</h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Real feedback from people I&apos;ve worked with
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="p-8 rounded-xl border border-border bg-card/50 backdrop-blur-sm space-y-4 hover:border-accent/50 hover:shadow-lg hover:shadow-accent/10 transition-all duration-300"
            >
              {/* Stars */}
              <div className="flex gap-1">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} size={18} className="fill-accent text-accent" />
                ))}
              </div>

              {/* Quote */}
              <p className="text-foreground/80 leading-relaxed italic">"{testimonial.content}"</p>

              {/* Author */}
              <div className="pt-4 border-t border-border">
                <p className="font-semibold text-foreground">{testimonial.name}</p>
                <p className="text-sm text-foreground/60">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
