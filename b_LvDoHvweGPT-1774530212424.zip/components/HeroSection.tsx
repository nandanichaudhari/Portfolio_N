'use client'

import Image from 'next/image'
import { ArrowRight, Github, Linkedin, Mail } from 'lucide-react'

export function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 pb-10 overflow-hidden">
      {/* Animated background gradient */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-in fade-in slide-in-from-left-8 duration-1000">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 text-accent border border-accent/20">
                <div className="w-2 h-2 rounded-full bg-accent animate-pulse"></div>
                <span className="text-sm font-medium">Available for projects</span>
              </div>

              <h1 className="text-5xl md:text-6xl font-bold leading-tight text-pretty">
                I Build Modern, <span className="bg-gradient-to-r from-accent to-accent/60 bg-clip-text text-transparent">Scalable</span> Web Experiences
              </h1>

              <p className="text-lg text-foreground/70 leading-relaxed">
                Full Stack Developer specializing in creating beautiful, functional web applications with React, Node.js, and modern technologies. Transforming ideas into reality.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#projects"
                className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-lg bg-primary text-primary-foreground font-semibold hover:shadow-lg hover:shadow-primary/20 transition-all duration-200 hover:scale-105"
              >
                View My Work
                <ArrowRight size={20} />
              </a>
              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-lg border border-border hover:bg-secondary/20 font-semibold transition-all duration-200"
              >
                Get In Touch
              </a>
            </div>

            {/* Social Links */}
            <div className="flex gap-4 pt-4">
              <a
                href="https://github.com/nandanichaudhari"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-secondary/20 hover:bg-accent/20 text-foreground/70 hover:text-accent transition-all duration-200 hover:scale-110"
                aria-label="GitHub"
              >
                <Github size={20} />
              </a>
              <a
                href="https://linkedin.com/in/nandani-chaudhari-9503362a4"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-secondary/20 hover:bg-accent/20 text-foreground/70 hover:text-accent transition-all duration-200 hover:scale-110"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="mailto:nandanichaudhari76@gmail.com"
                className="p-3 rounded-lg bg-secondary/20 hover:bg-accent/20 text-foreground/70 hover:text-accent transition-all duration-200 hover:scale-110"
                aria-label="Email"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>

          {/* Right Image */}
          <div className="relative animate-in fade-in slide-in-from-right-8 duration-1000 delay-200">
            <div className="relative w-full aspect-square max-w-md mx-auto">
              {/* Decorative elements */}
              <div className="absolute -inset-4 bg-gradient-to-r from-accent/20 to-primary/20 rounded-2xl blur-2xl opacity-60"></div>
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-transparent rounded-2xl"></div>

              <Image
                src="/profile.jpg"
                alt="Nandani Chaudhari"
                width={400}
                height={400}
                priority
                className="relative rounded-2xl w-full h-full object-cover shadow-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
