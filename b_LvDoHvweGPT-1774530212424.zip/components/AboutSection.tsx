'use client'

import { Code2, Database, Zap } from 'lucide-react'

export function AboutSection() {
  const skills = {
    frontend: ['React.js', 'Next.js', 'HTML5', 'CSS3', 'JavaScript', 'Tailwind CSS'],
    backend: ['Node.js', 'Express.js', 'Spring Boot', 'Java', 'Python', 'MongoDB'],
    tools: ['Git', 'GitHub', 'VS Code', 'Figma', 'Docker', 'Linux'],
  }

  return (
    <section id="about" className="py-20 bg-card/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <div className="inline-block px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
            <span className="text-accent text-sm font-semibold">ABOUT ME</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold">Crafting Digital Solutions</h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            I&apos;m a passionate developer dedicated to building scalable, user-centric web applications with modern technologies.
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          {/* Left Text */}
          <div className="space-y-6">
            <p className="text-foreground/80 leading-relaxed">
              Currently pursuing my B.Tech in Computer Science & Engineering, I bring hands-on experience in full-stack web development. As a Full Stack Developer Intern at Cepialab, I&apos;ve built responsive applications using React, Next.js, and Node.js with production-grade REST APIs and MongoDB databases.
            </p>
            <p className="text-foreground/80 leading-relaxed">
              I&apos;m particularly passionate about creating seamless user experiences and solving complex technical challenges. My background spans machine learning, AI-powered systems, and blockchain technology, allowing me to approach problems from multiple angles.
            </p>
            <div className="pt-4">
              <p className="text-sm text-foreground/60 mb-4">TECHNICAL EXPERTISE</p>
              <div className="grid grid-cols-3 gap-3">
                {['React', 'Node.js', 'MongoDB', 'REST APIs', 'Git', 'AWS'].map((tech) => (
                  <div
                    key={tech}
                    className="px-3 py-2 rounded-lg bg-accent/10 border border-accent/20 text-center text-sm font-medium text-accent"
                  >
                    {tech}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Skills */}
          <div className="space-y-8">
            {[
              { icon: Code2, title: 'Frontend', items: skills.frontend },
              { icon: Database, title: 'Backend', items: skills.backend },
              { icon: Zap, title: 'Tools & Platforms', items: skills.tools },
            ].map(({ icon: Icon, title, items }) => (
              <div key={title} className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-accent/20">
                    <Icon size={24} className="text-accent" />
                  </div>
                  <h3 className="text-lg font-semibold">{title}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {items.map((item) => (
                    <span
                      key={item}
                      className="px-3 py-1 rounded-full bg-secondary/30 text-foreground/80 text-sm"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-12 border-t border-border">
          {[
            { number: '4+', label: 'Major Projects' },
            { number: '6+', label: 'Technologies' },
            { number: '2', label: 'Internships' },
            { number: '100%', label: 'Dedication' },
          ].map(({ number, label }) => (
            <div key={label} className="text-center space-y-2">
              <p className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
                {number}
              </p>
              <p className="text-sm text-foreground/60">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
