'use client'

import { Code2, Palette, Zap, Bug, Database, Smartphone } from 'lucide-react'

const services = [
  {
    icon: Code2,
    title: 'Web Development',
    description: 'Build modern, responsive websites using React, Next.js, and Node.js with best practices and clean code.',
  },
  {
    icon: Palette,
    title: 'UI/UX Design',
    description: 'Create beautiful, user-friendly interfaces with thoughtful design and smooth animations.',
  },
  {
    icon: Zap,
    title: 'API Integration',
    description: 'Seamlessly integrate third-party APIs and build robust REST APIs for scalable applications.',
  },
  {
    icon: Bug,
    title: 'Bug Fixing',
    description: 'Quick, efficient debugging and problem-solving for existing applications and features.',
  },
  {
    icon: Database,
    title: 'Database Design',
    description: 'Design and optimize databases (MySQL, MongoDB) for performance and scalability.',
  },
  {
    icon: Smartphone,
    title: 'Responsive Design',
    description: 'Ensure your application works perfectly on all devices and screen sizes.',
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-card/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <div className="inline-block px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
            <span className="text-accent text-sm font-semibold">SERVICES</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold">What I Offer</h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Comprehensive solutions tailored to bring your vision to life
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map(({ icon: Icon, title, description }, index) => (
            <div
              key={index}
              className="group p-8 rounded-xl border border-border bg-card/50 backdrop-blur-sm hover:border-accent/50 hover:shadow-lg hover:shadow-accent/10 transition-all duration-300 space-y-4"
            >
              <div className="p-3 rounded-lg bg-accent/20 w-fit group-hover:bg-accent/30 transition-colors">
                <Icon size={28} className="text-accent" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">{title}</h3>
                <p className="text-foreground/70 leading-relaxed">{description}</p>
              </div>
              <div className="h-1 w-12 bg-gradient-to-r from-accent to-transparent rounded-full group-hover:w-full transition-all duration-300"></div>
            </div>
          ))}
        </div>

        {/* Process Section */}
        <div className="mt-20 pt-20 border-t border-border">
          <div className="text-center mb-12 space-y-4">
            <h3 className="text-3xl md:text-4xl font-bold">My Process</h3>
            <p className="text-foreground/70">How I turn ideas into exceptional web experiences</p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'Discovery', desc: 'Understanding your goals and requirements' },
              { step: '02', title: 'Design', desc: 'Creating intuitive and beautiful designs' },
              { step: '03', title: 'Development', desc: 'Building with clean, efficient code' },
              { step: '04', title: 'Delivery', desc: 'Testing and deployment to production' },
            ].map(({ step, title, desc }) => (
              <div key={step} className="relative">
                <div className="text-5xl font-bold text-accent/20 mb-2">{step}</div>
                <h4 className="text-xl font-bold mb-2">{title}</h4>
                <p className="text-foreground/70 text-sm">{desc}</p>
                {Number(step) < 4 && (
                  <div className="hidden md:block absolute -right-3 top-8 text-accent/40">→</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
