'use client'

import { Github, Linkedin, Mail, ExternalLink } from 'lucide-react'

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-card/50 border-t border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Nandani
            </h3>
            <p className="text-foreground/70 text-sm leading-relaxed">
              Full Stack Developer crafting modern web experiences with passion and precision.
            </p>
            <div className="flex gap-3">
              <a
                href="https://github.com/nandanichaudhari"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-secondary/20 hover:bg-accent/20 text-foreground/70 hover:text-accent transition-all duration-200"
                aria-label="GitHub"
              >
                <Github size={20} />
              </a>
              <a
                href="https://linkedin.com/in/nandani-chaudhari-9503362a4"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-secondary/20 hover:bg-accent/20 text-foreground/70 hover:text-accent transition-all duration-200"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="mailto:nandanichaudhari76@gmail.com"
                className="p-2 rounded-lg bg-secondary/20 hover:bg-accent/20 text-foreground/70 hover:text-accent transition-all duration-200"
                aria-label="Email"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold">Navigation</h4>
            <nav className="space-y-2 flex flex-col">
              {['Home', 'About', 'Projects', 'Services', 'Contact'].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-foreground/70 hover:text-accent transition-colors text-sm"
                >
                  {item}
                </a>
              ))}
            </nav>
          </div>

          {/* Skills */}
          <div className="space-y-4">
            <h4 className="font-semibold">Skills</h4>
            <div className="space-y-2 text-sm text-foreground/70">
              <p>React · Next.js · Node.js</p>
              <p>JavaScript · Python · Java</p>
              <p>MongoDB · MySQL · REST API</p>
              <p>Git · Docker · AWS</p>
            </div>
          </div>

          {/* CTA */}
          <div className="space-y-4">
            <h4 className="font-semibold">Ready to Build?</h4>
            <p className="text-foreground/70 text-sm">
              Let&apos;s create something amazing together. Get in touch today.
            </p>
            <a
              href="mailto:nandanichaudhari76@gmail.com"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-accent text-accent-foreground font-semibold hover:shadow-lg hover:shadow-accent/20 transition-all text-sm"
            >
              Start Project
              <ExternalLink size={16} />
            </a>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-foreground/60">
          <p>&copy; {currentYear} Nandani Chaudhari. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-foreground/80 transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-foreground/80 transition-colors">
              Terms of Service
            </a>
            <a href="#" className="hover:text-foreground/80 transition-colors">
              Sitemap
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
